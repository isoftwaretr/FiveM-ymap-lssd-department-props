Custom License Agreement

By using this file, you agree to the following terms and conditions:

**Personal Use Only**:
   - You are granted the right to use this file for personal, non-commercial purposes only.

**No Commercial Use**:
   - You may not sell, rent, lease, sublicense, or otherwise exploit this file for any commercial purposes.

**No Redistribution for Profit**:
   - You may not redistribute this file in a way that allows others to sell, rent, lease, sublicense, or otherwise exploit it for commercial purposes.

**Modifications**:
   - You are allowed to modify this file for personal use. However, modified versions of this file are also subject to the same terms and conditions stated in this license.

**Attribution**:
   - You must include an attribution to the original author (iSoftware®) when sharing the modified file for personal use.

**Liability**:
   - This file is provided "as-is," without warranty of any kind. The author is not liable for any damages arising from its use.

**Termination**:
   - Any violation of these terms will result in the immediate termination of your rights under this license.

For any questions or further permissions, please contact the original author at info@isoftware.com.tr.

© 2024 iSoftware®. All rights reserved.

Website: https://isoftware.com.tr
Instagram: https://instagram.com/isoftwarecomtr
Facebook: https://facebook.com/isoftware
LinkedIn: https://linkedin.com/company/isoftwarecomtr

